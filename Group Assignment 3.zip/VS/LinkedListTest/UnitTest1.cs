namespace LinkedListTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test_EmptyMethod()
        {
            Assert.Pass();
        }

        [Test]
        public void Test_AddFirstMethod() 
        {

        }

        [Test]
        public void Test_AddLastMethod()
        {

        }

        [Test]
        public void Test_AddMethod()
        {

        }

        [Test]
        public void Test_ReplaceMethod()
        {

        }

        [Test]
        public void Test_RemoveFirstMethod()
        {

        }

        [Test]
        public void Test_RemoveLastMethod()
        {

        }

        [Test]
        public void Test_RemoveMethod()
        {

        }

        [Test]
        public void Test_
    }
}