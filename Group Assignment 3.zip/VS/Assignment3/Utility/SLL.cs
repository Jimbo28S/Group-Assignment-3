﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Utility
{
    public class SLL<T> : ILinkedListADT
    {
        public Node Head {  get; set; }
        public Node Tail { get; set; }
        public int Length { get; set; }

        public SLL() 
        {
            this.Head = null;
            this.Tail = null;
        }

        public bool IsEmpty()
        {
            if (Head == null) return true;
            else return false;
        }

        public void Clear()
        {
            
        }

        public void AddLast(User value)
        {
            // If list is empty
            if (Head == null)
            {
                Head = new Node(value);
                Head.Next = Head;
            }
            else
            {
                if (Tail == null)
                {
                    Tail = new Node(value);
                    Head.Next = Tail;
                }
                else
                {
                    Node addTail = new Node(Tail.Value);
                    Tail.Value = value;
                    addTail.Next = Tail;
                }
                
            }
        }

        public void AddFirst(User value)
        {
            // If list is empty
            if (Head == null)
            {
                Head = new Node(value);
                Head.Next = null;
            }
            // If list is not empty
            else
            {
                // Copy first node value and pointer to new node
                // Set first node's value to given value
                // Set first node's pointer to the new node
                Node newNode = new Node(value);
                newNode.Next = Head;
                Head = newNode; 
            }
            Length++;
        }

        public void Add(User value, int index) 
        {
            Node newNode = new Node(value);
            
            if (index == 0)
            {
                newNode.Next = Head;
                Head = newNode;
            }

            Node currentNode = Head;
            int indexCounter = 0;

            while (currentNode != null && indexCounter < index - 1)
            {
                currentNode = currentNode.Next;
                indexCounter++;
            }

            newNode.Next = currentNode.Next;
            currentNode.Next = newNode;
        }

        public void Replace(User value, int index)
        {
            Node currentNode = Head;
            int indexCounter = 0;
            string loopControl = "looping";

            while (loopControl != null)
            {
                currentNode = currentNode.Next;
                indexCounter++;
                if (indexCounter == index)
                {
                    currentNode.Value = value;
                    loopControl = null;
                }
            }
        }

        public int Count() 
        {
            Node currentNode = Head;
            int indexCounter = 1;

            while (currentNode != null)
            {
                currentNode = currentNode.Next;
                indexCounter++;
            }
            return indexCounter;

        }

        public void RemoveFirst()
        {
            if (Head != null)
            {
                Head = Head.Next;
            }
        }

        public void RemoveLast()
        {
            if (Head.Next == null)
            {
                Head = null;
            }
            else
            {
                Node currentNode = Head;
                while (currentNode.Next != null)
                {
                    currentNode = currentNode.Next;
                }
                currentNode.Next = null;
                Tail = currentNode;
            }
        }

        public void Remove(int index)
        {
            if (index == 0) 
            {
                RemoveFirst();
            }

            if (index == Count() - 1)
            {
                RemoveLast();
            }
            else
            {
                Node currentNode = Head;
                int indexCounter = 0;
                while (indexCounter != index - 1)
                {
                    currentNode = currentNode.Next;
                    indexCounter++;
                }
                currentNode.Next = currentNode.Next.Next;
            }
        }

        public User GetValue(int index)
        {
            Node currentNode = Head;
            currentNode.Value = Head.Value;
            currentNode.Next = Head.Next;
            int indexCounter = 0;
            while (indexCounter != index)
            {
                currentNode = currentNode.Next;
                indexCounter++;
            }
            return currentNode.Value;
        }

        public int IndexOf(User value)
        {
            Node currentNode = Head;
            currentNode.Value = Head.Value;
            currentNode.Next = Head.Next;
            int indexCounter = 0;
            while (!currentNode.Value.Equals(value))
            {
                currentNode = currentNode.Next;
                indexCounter++;
            }
            return indexCounter;
        }

        public bool Contains(User value)
        {
            Node currentNode = Head;
            while (currentNode != null)
            {
                if (currentNode.Value.Equals(value)) { return true; }
                else { currentNode = currentNode.Next; }
                
            }       
            return false;
        }

        public void SplitSLL(int index)
        {
            Node currentNode = Head;
            int indexCounter = 0;
            while (indexCounter != index)
            {
                currentNode = currentNode.Next;
                indexCounter++;
            }
            Tail = currentNode;
            Tail.Next = null;
        }
    }
}
